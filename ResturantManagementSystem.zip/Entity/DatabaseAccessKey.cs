﻿namespace RMS.Entity
{
    public enum DatabaseAccessKey
    {
        Insert = 1,
        Update=2
    }
}
